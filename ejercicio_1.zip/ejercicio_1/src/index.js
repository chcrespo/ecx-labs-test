const express = require('express');
const app = express();

// Configuración
app.set('port', process.env.PORT || 3000);

// Middleware
app.use(express.json());

// Rutas
app.use(require('./routes/currency'));

// Iniciar el servidor
app.listen(app.get('port'), () => {
    console.log('Servidor en puerto', app.get('port'));
});